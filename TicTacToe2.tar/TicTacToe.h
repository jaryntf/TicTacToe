
#ifndef TICTACTOE_H_INCLUDED
#define TICTACTOE_H_INCLUDED
using namespace std; // all functions defined here


void updateBoard(string a,string b, int c);
void playerTurn();
int checkBoard();
void computerTurn();
void saveBoard(int x,string y);

#endif // TICTACTOE_H_INCLUDED
